<?php
$con= new PDO("mysql:host=localhost;dbname=ngo_db", "root","");
?>